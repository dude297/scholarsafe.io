# ScholarSafe — Safe Places. Bright Futures.

Student housing platform with verified listings, safety scores, and roommate matching.

**Stack:** Next.js 14 · Tailwind CSS · Supabase · Lucide React

---

## Quick Start

### 1. Install dependencies
```bash
npm install
```

### 2. Set up Supabase
1. Create a project at [supabase.com](https://supabase.com)
2. Go to **SQL Editor → New Query**
3. Paste the contents of `scholarsafe-schema.sql` and click **Run**

### 3. Add environment variables
Copy `.env.example` to `.env.local` and fill in your values:
```bash
cp .env.example .env.local
```

Find both values in **Supabase → Project Settings → API**:
```
NEXT_PUBLIC_SUPABASE_URL=https://your-project-id.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key-here
```

### 4. Run locally
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000)

---

## Deploy to Vercel

1. Push this repo to GitHub
2. Go to [vercel.com](https://vercel.com) → **Add New Project** → import your repo
3. Add your env vars under **Settings → Environment Variables**:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
4. Click **Deploy** — Vercel auto-detects Next.js

Every `git push` to `main` triggers a new production deploy automatically.

---

## Project Structure
```
scholarsafe/
├── app/
│   ├── page.jsx          # Full landing page (Header · Hero · Waitlist · Footer)
│   ├── layout.jsx        # Root layout + metadata
│   └── globals.css       # Tailwind + Google Fonts + keyframes
├── scholarsafe-schema.sql # Paste into Supabase SQL Editor
├── .env.example          # Copy to .env.local and fill in values
├── next.config.mjs
├── tailwind.config.js
└── package.json
```

---

## Built by
Zainah Fatimah · Farhiya Mohamed · Danna Kholaif
