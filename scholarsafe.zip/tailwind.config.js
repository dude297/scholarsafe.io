/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,jsx,ts,tsx}",
    "./components/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        display: ["'Playfair Display'", "serif"],
        sans:    ["'DM Sans'", "sans-serif"],
      },
      colors: {
        navy:  "#1a2b5e",
        gold:  "#c9a227",
        cream: "#f8f5f0",
        safe:  "#22c55e",
        warn:  "#f59e0b",
      },
    },
  },
  plugins: [],
};
