import "./globals.css";

export const metadata = {
  title:       "ScholarSafe — Safe Places. Bright Futures.",
  description: "The only student housing platform with verified listings, real student reviews, neighborhood safety scores, and compatible roommate matching — all in one place.",
  keywords:    ["student housing", "safe housing", "college apartments", "roommate matching", "campus housing"],
  openGraph: {
    title:       "ScholarSafe — Safe Places. Bright Futures.",
    description: "Find safe, affordable student housing near your campus.",
    type:        "website",
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
